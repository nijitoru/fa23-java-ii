
public class MenuException extends Exception {
	public MenuException(String choice) {
		super(choice);
	}
}
